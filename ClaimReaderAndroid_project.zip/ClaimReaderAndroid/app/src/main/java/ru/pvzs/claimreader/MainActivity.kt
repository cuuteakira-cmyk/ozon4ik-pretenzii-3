package ru.pvzs.claimreader

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private val pickCode = 42
    private lateinit var status: TextView
    private lateinit var pvz: EditText
    private lateinit var dateField: EditText
    private lateinit var amount: EditText
    private lateinit var claimType: EditText
    private lateinit var claimId: EditText
    private lateinit var rawText: EditText
    private lateinit var rows: MutableList<List<String>>
    private var lastCsv = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rows = mutableListOf()
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 28) }
        scroll.addView(root)
        setContentView(scroll)
        root.addView(TextView(this).apply { text = "Претензии ПВЗ"; textSize = 27f; setTextColor(0xFF183B70.toInt()) })
        root.addView(TextView(this).apply { text = "Загрузка скриншота → распознавание → проверка данных → экспорт CSV для Excel/Google Таблиц."; textSize = 15f; setPadding(0, 8, 0, 18) })
        button(root, "Выбрать скриншоты") { pickImages() }
        status = TextView(this).apply { text = "Пока нет загруженных скриншотов."; setPadding(0, 12, 0, 12) }
        root.addView(status)
        pvz = field(root, "ПВЗ / адрес", "Например: Сокол")
        dateField = field(root, "Дата претензии", "ДД.ММ.ГГГГ")
        amount = field(root, "Сумма удержания, ₽", "Если указана")
        claimType = field(root, "Причина / тип", "Например: нарушение процесса")
        claimId = field(root, "Номер претензии", "Если указан")
        root.addView(TextView(this).apply { text = "Распознанный текст (можно исправить вручную)"; setPadding(0, 12, 0, 6) })
        rawText = EditText(this).apply { minLines = 6; gravity = android.view.Gravity.TOP; hint = "Здесь появится текст со скриншота" }
        root.addView(rawText, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        button(root, "Сохранить запись в таблицу") { saveRow() }
        button(root, "Экспортировать CSV для Excel") { exportCsv() }
        button(root, "Очистить форму") { rawText.setText(""); dateField.setText(""); amount.setText(""); claimType.setText(""); claimId.setText("") }
        root.addView(TextView(this).apply { text = "Важно: приложение — первая версия. Всегда проверяй распознанные суммы, даты и номера перед сохранением. Скриншоты обрабатываются на устройстве; файл языка русского OCR загружается из интернета при первом распознавании."; textSize = 12f; setPadding(0, 18, 0, 0) })
    }

    private fun field(root: LinearLayout, label: String, hintText: String): EditText {
        root.addView(TextView(this).apply { text = label; setPadding(0, 10, 0, 3) })
        return EditText(this).apply { hint = hintText; singleLine = true }.also { root.addView(it, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)) }
    }

    private fun button(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text = label; setOnClickListener { action() } }, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun pickImages() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, pickCode)
    }

    @Deprecated("Deprecated by platform API; retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != Activity.RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        status.text = "Распознаю ${uris.size} изображений…"
        thread {
            try {
                val all = StringBuilder()
                for ((index, uri) in uris.withIndex()) {
                    val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: continue
                    val text = runOcr(bitmap)
                    all.append("\n--- Скриншот ${index + 1} ---\n").append(text).append("\n")
                    bitmap.recycle()
                }
                runOnUiThread {
                    rawText.setText(all.toString().trim())
                    autoFill(all.toString())
                    status.text = "Готово: ${uris.size} изображений. Проверь поля и распознанный текст."
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Не удалось распознать: ${e.message ?: "ошибка"}. Проверь интернет и попробуй ещё раз." }
            }
        }
    }

    private fun runOcr(bitmap: android.graphics.Bitmap): String {
        val base = File(filesDir, "tesseract")
        val tessdata = File(base, "tessdata")
        if (!tessdata.exists()) tessdata.mkdirs()
        val trained = File(tessdata, "rus.traineddata")
        if (!trained.exists() || trained.length() < 100000) {
            val url = URL("https://github.com/tesseract-ocr/tessdata_fast/raw/main/rus.traineddata")
            val connection = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 20000; readTimeout = 30000; instanceFollowRedirects = true }
            connection.inputStream.use { input -> FileOutputStream(trained).use { output -> input.copyTo(output) } }
            connection.disconnect()
        }
        val api = TessBaseAPI()
        if (!api.init(base.absolutePath, "rus+eng")) throw IllegalStateException("Не удалось запустить OCR")
        api.setImage(bitmap)
        val result = api.utF8Text ?: ""
        api.end()
        return result
    }

    private fun autoFill(text: String) {
        val dateRegex = Regex("\\b(\\d{2}[./-]\\d{2}[./-]\\d{2,4})\\b")
        dateRegex.find(text)?.value?.let { dateField.setText(it) }
        val moneyRegex = Regex("(?i)(?:₽|руб(?:лей|ля|\.)?)?\\s*(\\d{1,3}(?:[ \\u00A0]\\d{3})*(?:[.,]\\d{1,2})?)\\s*(?:₽|руб(?:лей|ля|\.)?)")
        moneyRegex.find(text)?.groupValues?.getOrNull(1)?.let { amount.setText(it.replace(" ", "").replace(',', '.')) }
        val idRegex = Regex("(?i)(?:претенз(?:ия|ии)|claim|№)\\s*[:№#-]?\\s*([A-ZА-Я0-9-]{4,})")
        idRegex.find(text)?.groupValues?.getOrNull(1)?.let { claimId.setText(it) }
    }

    private fun saveRow() {
        val text = rawText.text.toString().trim()
        if (text.isBlank()) { Toast.makeText(this, "Сначала загрузи скриншот или введи текст", Toast.LENGTH_SHORT).show(); return }
        val row = listOf(pvz.text.toString(), dateField.text.toString(), claimId.text.toString(), claimType.text.toString(), amount.text.toString(), text.replace("\n", " "))
        rows.add(row)
        status.text = "Записей в таблице: ${rows.size}"
        Toast.makeText(this, "Запись добавлена", Toast.LENGTH_SHORT).show()
        rawText.setText(""); dateField.setText(""); claimId.setText(""); claimType.setText(""); amount.setText("")
    }

    private fun exportCsv() {
        if (rows.isEmpty()) { Toast.makeText(this, "Сначала сохрани хотя бы одну запись", Toast.LENGTH_SHORT).show(); return }
        val header = listOf("ПВЗ", "Дата", "Номер претензии", "Причина", "Сумма удержания, ₽", "Распознанный текст")
        fun esc(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val csv = (listOf(header) + rows).joinToString("\r\n") { row -> row.joinToString(";") { esc(it) } }
        val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir
        val file = File(dir, "pretenzii_pvz_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.csv")
        file.writeText("\uFEFF$csv", Charsets.UTF_8)
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        // FileProvider is configured below via manifest metadata.
        val share = Intent(Intent.ACTION_SEND).apply { type = "text/csv"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(share, "Сохранить или отправить CSV"))
        status.text = "Экспорт подготовлен: ${rows.size} записей."
    }
}
